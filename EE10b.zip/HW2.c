/*
David Kornfeld
EE10b HW2 pt1

Overall Pseudo-Code
    None
*/

//Function Prototypes ###########################################################################
//Accessors
    int LRSwitch(void);
    int UDSwitch(void);
    int LeftRot(void);
    int RightRot(void);
    int DownRot(void);
    int UpRot(void);
// Utility Code 
    void Rot_Enc_GPIOInit(void);
    void InitClocks(void);
    void InitVariables(void);
    void msElapsedInterruptHandler(void);
// Functions taken as givens
    int digitalRead(pin);
    void clear_flag(flag);
    void set_flag(flag);
    void set_timer_interrupt(callback_function, prescaler);
// ##############################################################################################

// Pin Declarations (definitions will come in assembly) #########################################
#define LR_SWITCH       // l/r pushbutton switch input pin
#define UD_SWITCH       // u/d pushbutton switch input pin
#define LR_ROT_ENC_1    // l/r rotary encoder input 1 pin
#define LR_ROT_ENC_2    // l/r rotary encoder input 2 pin
#define UD_ROT_ENC_1    // u/d rotary encoder input 1 pin
#define UD_ROT_ENC_2    // u/d rotary encoder input 2 pin

// ##############################################################################################

// Accessors ------------------------------------------------------------------------------------
int LRSwitch(void)
/*
Description:    This procedure is an accessor for the status of the left/right 
                pushbutton switch. If the switch has been held down for a sufficient 
                amount of time (debounced), then the zero flag is set. Otherwise it 
                is cleared.

Arguments:      None.
Return Values:  Zero Flag. Set if LRSwitch has been pressed. Cleared otherwise.

Shared Variables:   zero flag - set to indicate if switch is pressed
                    lr_switch_flag – accessed to determined if debouncce has
                    finished and there has been a new press.
Global Variables:   None.
Local Variables:    None.
            
Input:          None.
Output:         None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
{
    if (lr_switch_flag == TRUE)
    {
        set_flag(zero); // Set the zero flag. Was a press
    }
    else
    {
        clear_flag(zero); // Clear the zero flag. No press
    }
    clear_flag(lr_switch_flag); // Reset the press flag to prevent repeat if switch held down
}

int LRSwitch(void)
/*
Description:    This procedure is an accessor for the status of the up/down 
                pushbutton switch. If the switch has been held down for a sufficient 
                amount of time (debounced), then the zero flag is set. Otherwise it 
                is cleared.

Arguments:      None.
Return Values:  Zero Flag. Set if UDSwitch has been pressed. Cleared otherwise.

Shared Variables:   zero flag - set to indicate if switch is pressed
                    ud_switch_flag – accessed to determined if debouncce has
                    finished and there has been a new press.
Global Variables:   None.
Local Variables:    None.

Input:          None.
Output:         None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
{
    if (ud_switch_flag == TRUE)
    {
        set_flag(zero); // Set the zero flag. Was a press
    }
    else
    {
        clear_flag(zero); // Clear the zero flag. No press
    }
    clear_flag(ud_switch_flag); // Reset the press flag to prevent repeat if switch held down
}

int LeftRot(void)
/*
Description:    This procedure is an accessor for the status of the left/right 
                rotary encoder. If the encoder has been turned left since the last
                call of this function. The zero flag is set. Otherwise it is cleared.

Arguments:      None.
Return Values:  Zero Flag. Set if a left rotation has occured. Cleared otherwise.

Shared Variables:   zero flag - set to indicate if switch is pressed
                    l_rot_flag – accessed to determined if there has been a left rotation
Global Variables:   None.
Local Variables:    None.

Input:          None.
Output:         None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
{
    if (l_rot_flag == TRUE)
    {
        set_flag(zero); // Set the zero flag. Was a press
    }
    else
    {
        clear_flag(zero); // Clear the zero flag. No press
    }
    clear_flag(l_rot_flag); // Reset the press flag to prevent repeat
}

int RightRot(void)
/*
Description:    This procedure is an accessor for the status of the left/right 
                rotary encoder. If the encoder has been turned right since the last
                call of this function. The zero flag is set. Otherwise it is cleared.

Arguments:      None.
Return Values:  Zero Flag. Set if a right rotation has occured. Cleared otherwise.

Shared Variables:   zero flag - set to indicate if switch is pressed
                    r_rot_flag – accessed to determined if there has been a right rotation
Global Variables:   None.
Local Variables:    None.

Input:          None.
Output:         None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
{
    if (r_rot_flag == TRUE)
    {
        set_flag(zero); // Set the zero flag. Was a press
    }
    else
    {
        clear_flag(zero); // Clear the zero flag. No press
    }
    clear_flag(r_rot_flag); // Reset the press flag to prevent repeat
}

int DownRot(void)
/*
Description:    This procedure is an accessor for the status of the up/down
                rotary encoder. If the encoder has been turned down (left) since the last
                call of this function. The zero flag is set. Otherwise it is cleared.

Arguments:      None.
Return Values:  Zero Flag. Set if a "down" rotation has occured. Cleared otherwise.

Shared Variables:   zero flag - set to indicate if switch is pressed
                    d_rot_flag – accessed to determined if there has been a "down" rotation
Global Variables:   None.
Local Variables:    None.

Input:          None.
Output:         None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
{
    if (d_rot_flag == TRUE)
    {
        set_flag(zero); // Set the zero flag. Was a press
    }
    else
    {
        clear_flag(zero); // Clear the zero flag. No press
    }
    clear_flag(d_rot_flag); // Reset the press flag to prevent repeat
}

int UpRot(void)
/*
Description:    This procedure is an accessor for the status of the up/down
                rotary encoder. If the encoder has been turned up (right) since the last
                call of this function. The zero flag is set. Otherwise it is cleared.

Arguments:      None.
Return Values:  Zero Flag. Set if a "up" rotation has occured. Cleared otherwise.

Shared Variables:   zero flag - set to indicate if switch is pressed
                    u_rot_flag – accessed to determined if there has been a "up" rotation
Global Variables:   None.
Local Variables:    None.

Input:          None.
Output:         None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
{
    if (u_rot_flag == TRUE)
    {
        set_flag(zero); // Set the zero flag. Was a press
    }
    else
    {
        clear_flag(zero); // Clear the zero flag. No press
    }
    clear_flag(u_rot_flag); // Reset the press flag to prevent repeat
}

// Utility Functions ----------------------------------------------------------------------------
void Rot_Enc_GPIOInit(void)
{
/*
Description:    This procedure initializes the rotary encoder GPIO pins by writing by writing to
                the proper registers (TBD)

Arguments:      None.
Return Values:  None

Global Variables:   None.
Shared Variables:   None.
Local Variables:    None.
            
Input:          LR_SWITCH - pin for l/r pushbutton
                UD_SWITCH - pin for u/d pushbutton
                LR_ROT_ENC_1 - pin for l/r rotary encoder pin 1
                LR_ROT_ENC_2 - pin for l/r rotary encoder pin 2
                UD_ROT_ENC_1 - pin for u/d rotary encoder pin 1
                UD_ROT_ENC_2 - pin for u/d rotary encoder pin 2
Output:         None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Declare rotary encoders and their pushbuttons as digital inputs
    pinMode(LR_ROT_ENC_1, digital input);
    pinMode(LR_ROT_ENC_2, digital input);
    pinMode(UD_ROT_ENC_1, digital input);
    pinMode(UD_ROT_ENC_2, digital input);
    pinMode(LR_SWITCH, digital input);
    pinMode(UD_SWITCH, digital input);
}

void InitClocks(void)
{
/*
Description:    This procedure initializes the clocks for timer interrupts by writing to the
                proper registers (TBD)

Arguments:      None.
Return Values:  None

Global Variables:   None.
Shared Variables:   None.
Local Variables:    None.
            
Input:          None.
Output:         None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // set an interrupt to be called every 1ms in the msElapsedInterrupt function
    set_timer_interrupt(msElapsedInterrupt, 1MS_PRESCALER); 
}


void InitVariables(void)
{
/*
Description:    This procedure initializes the shared variables for user input

Arguments:      None
Return Values:  None

Shared Variables:   l_rot_flag - Flags for direction(s) moved
                    r_rot_flag
                    u_rot_flag
                    d_rot_flag
                    lr_switch_flag - Flags for pushbutton switch status
                    ud_switch_flag
                    ud_debounce_ctr - Debounce counters for pushbuttons
                    lr_debonuce_ctr
                    lr_rot_enc_struct - Structs for rotary encoders
                    ud_rot_enc_struct
Global Variables:   None.
Local Variables:    None.
            
Input:          None.
Output:         None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    rot_enc_struct
                        int lastReached - last encoder state reached
                        int reached00 - boolean for if 00 was reached
                        int reached01 - boolean for if 01 was reached
                        int reached10 - boolean for if 10 was reached
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Clear all flags
    clear_flag(l_rot_flag);
    clear_flag(r_rot_flag);
    clear_flag(u_rot_flag);
    clear_flag(d_rot_flag);
    clear_flag(lr_switch_flag);
    clear_flag(ud_switch_flag);
    // Reset debounce counters
    ud_debounce_ctr = DEBOUNCE_TIME;
    lr_debonuce_ctr = DEBOUNCE_TIME;
    // Clear all fields of encoder structs
    lr_rot_enc_struct.lastReached = 00;
    lr_rot_enc_struct.reached00 = FALSE;
    lr_rot_enc_struct.reached01 = FALSE;
    lr_rot_enc_struct.reached10 = FALSE;

    ud_rot_enc_struct.lastReached = 00;
    ud_rot_enc_struct.reached00 = FALSE;
    ud_rot_enc_struct.reached01 = FALSE;
    ud_rot_enc_struct.reached10 = FALSE;
}

void msElapsedInterruptHandler(void)
{
/*
Description:    This procedure updates debounce counters (and their matching flags) along 
                with anything else that should change on a ms scale.

Arguments:      None
Return Values:  None
Local Variables:    lr_rot_enc_1_status - status of the l/r rotary encoder pin 1
                    ud_rot_enc_1_status - status of the u/d rotary encoder pin 1
                    lr_rot_enc_2_status - status of the l/r rotary encoder pin 2
                    ud_rot_enc_2_status - status of the u/d rotary encoder pin 2

Shared Variables:   lr_debonuce_ctr - counter for debouncing the left/right pushbutton
                    ud_debonuce_ctr - counter for debouncing the up/down pushbutton
                    lr_switch_flag - set if the debounce runs out on L/R pushbutton
                    ud_switch_flag - set if the debounce runs out on U/D pushbutton

                    lr_rot_enc_struct - set by status of encoder pins. Used to calc l/r flags
                    ud_rot_enc_struct - set by status of encoder pins. Used to calc u/d flags
                    l_rot_flag - set if left rotation occured
                    r_rot_flag - set if right rotation occured
Global Variables:   None

            
Input:          LR_SWITCH - pin for l/r pushbutton
                UD_SWITCH - pin for u/d pushbutton
                LR_ROT_ENC_1 - pin for l/r rotary encoder pin 1
                LR_ROT_ENC_2 - pin for l/r rotary encoder pin 2
                UD_ROT_ENC_1 - pin for u/d rotary encoder pin 1
                UD_ROT_ENC_2 - pin for u/d rotary encoder pin 2
Output:         None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    rot_enc_struct
                        int lastReached - last encoder state reached
                        int reached00 - boolean for if 00 was reached
                        int reached01 - boolean for if 01 was reached
                        int reached10 - boolean for if 10 was reached
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Handle left/right switch debouncing
    if(digitalRead(LR_SWITCH) == FALSE)
    {
        lr_debonuce_ctr = DEBOUNCE_TIME; // Switch not pressed, so don't count down
    }
    else
    {
        lr_debounce_ctr --; // Count down since switch pressed
        if(lr_debounce_ctr == 0)
        {
            set_flag(lr_switch_flag); // set the switch flag if debounce is complete
        }
        else if(lr_debounce_ctr <= 0)
        {
            lr_debounce_ctr = 0; // Prevent wrapping back around
        }
    }

    // Handle up/down switch debouncing
    if(digitalRead(UD_SWITCH) == FALSE)
    {
        ud_debonuce_ctr = DEBOUNCE_TIME; // Switch not pressed, so don't count down
    }
    else
    {
        ud_debounce_ctr --; // Count down since switch pressed
        if(ud_debounce_ctr == 0)
        {
            set_flag(ud_switch_flag); // set the switch flag if debounce is complete
        }
        else if(ud_debounce_ctr <= 0)
        {
            ud_debounce_ctr = 0; // Prevent wrapping back around
        }
    }

    // Handle l/r rotary encoder states
    lr_rot_enc_1_status = digitalRead(LR_ROT_ENC_1); // Read in the status of the pins (1 or 0);
    lr_rot_enc_2_status = digitalRead(LR_ROT_ENC_2);
    lr_rot_direction = rot_encoder_handler(&lr_rot_enc_struct, lr_rot_enc_1_status, lr_rot_enc_2_status);
    if (lr_rot_direction == LEFT)
    {
        set_flag(l_rot_flag);
    }
    else if (lr_rot_direction == RIGHT)
    {
        set_flag(r_rot_flag);
    }

    // Handle u/d rotary encoder states
    ud_rot_enc_1_status = digitalRead(UD_ROT_ENC_1); // Read in the status of the pins (1 or 0);
    ud_rot_enc_2_status = digitalRead(UD_ROT_ENC_2);
    ud_rot_direction = rot_encoder_handler(&ud_rot_enc_struct, ud_rot_enc_1_status, ud_rot_enc_2_status);
    if (ud_rot_direction == LEFT)
    {
        set_flag(d_rot_flag);
    }
    else if (ud_rot_direction == RIGHT)
    {
        set_flag(u_rot_flag);
    }
}

direction rot_encoder_handler((rot_enc_struct *) rot_enc, int enc_status1, int enc_status2)
{
/*
Description:    This procedure handles rotary encoder transitions, returning the direction
                it rotated, (if any) and keeping track of internal struct variables

Arguments:      rot_enc - a pointer to a rotary encoder struct
                enc_status1 - most recent read position of the encoder status pin 1
                enc_status2 - most recent read position of the encoder status pin 2
Return Values:  direction (CCW if rotated counter-clockwise, CW if rotated clockwise, 
                            NONE if didn't complete a rotation)

Local Variables:    returnDirection - the direction to be returned. Stored until the end
                                        of the procedure.
Global Variables:   None.
Shared Variables:   None.
            
Input:          None.
Output:         None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    rot_enc_struct
                        int lastReached - last encoder state reached
                        int reached00 - boolean for if 00 was reached
                        int reached01 - boolean for if 01 was reached
                        int reached10 - boolean for if 10 was reached
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    switch (enc_status1, enc_status2):
        case (1, 1): // 1 high, 2 high
            rot_enc.reached11 = TRUE; // mark this position as reached
            rot_enc.lastReached = 11;
            return NONE;
        case (1, 0): // 1 high, 2 low
            rot_enc.reached10 = TRUE; // mark this position as reached
            rot_enc.lastReached = 10;
            return NONE;
        case (0, 1): // 1 low, 2 high
            rot_enc.reached01 = TRUE; // mark this position as reached
            rot_enc.lastReached = 01;
            return NONE;
        case (0, 0): // both low. At a detent position
            // If we have made a full rotation
            if(rot_enc_struct.reached11 && rot_enc_struct.reached10 && rot_enc_struct.reached01)
            {
                if(rot_enc.lastReached == 10)
                {
                    returnDirection = CCW; // if turning counter-clockwise and did a full rotation then 
                                            // return CCW
                }
                else if(rot_enc.lastReached == 01)
                {
                    returnDirection = CW; // if turning clockwise and did a full rotation then 
                                            // return CW
                }
            }
            // Clear all "reached" flags and set new most recent position
            rot_enc.11reached = FALSE;
            rot_enc.10reached = FALSE;
            rot_enc.01reached = FALSE;
            rot_enc.lastReached = 00;
            return returnDirection;
}