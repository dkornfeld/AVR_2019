/*
David Kornfeld
EE10b HW3 pt1
*/

// Functions taken as givens
void InitClocks();
void clear_flag(flag);
void set_flag(flag);
void portMode(port, mode);
void writePort(port, uint8_t data);

// Utility Code
void displayGPIOInit();
void initDisplayVars();
void HandleDisplay();

// Function prototypes
void ClearDisplay();
void PlotPixel(uint8_t row, uint8_t col, uint8_t color);
void SetCursor(uint8_t row, uint8_t col, uint8_t on_color, uint8_t off_color);

// Declarations                 
                      //Indices    0   1   2   3   4   5   6   7
#define ROW_PORT        PORTC   //[C7, C6, C5, C4, C3, C2, C1, C0]
#define RED_COL_PORT    PORTD   //[D0, D1, D2, D3, D4, D5, D6, D7]
#define GREEN_COL_PORT  PORTA   //[A7, A6, A5, A4, A3, A2, A1, A0]

#define PORT_MODE_OUTPUT 0xFF

#define CURSOR_TOGGLE_TIME 500 //ms

#define OFF     0
#define RED     1
#define GREEN   2 
#define YELLOW  3

#define NUM_COLS 8

// Shared variables
uint8_t displayBuf[2 * NUM_COLS]; // The display buffer, array of columns,
                                  // first red, then green
uint8_t col_pattern_low; // Used to keep track of which column we're muxing
uint8_t col_pattern_high;
uint16_t BufLoc; // Pointer to current muxing location in display buffer
uint8_t cursor_row; // Location of the cursor
uint8_t cursor_col;
uint8_t cursor_on_color; // On color of the cursor
uint8_t cursor_off_color; // Off color of the cursor
flag    cursor_on; // Flag for if cuursor is on
uint16_t cursor_counter; // Keeps track of how long cursor has been on/off


void ClearDisplay()
{
/*
Description:    This procedure modifies the display buffer such that it will
                be entirely empty except for the cursor.

Arguments:          None.
Return Values:      None.

Shared Variables:   displayBuf.
Global Variables:   None.
Local Variables:    count   - used to make sure we only affect displayBuf
                    address - the offset from the start of displayBuf in 
                              memory
            
Input:              None.
Output:             None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    Array.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    uint16_t address = &displayBuf;
    uint8_t count = 0;
    while(count < 2 * NUM_COLS)
    {
        *(address++) = 0x00; // set every bit of that col to OFF (0)
                             // and increment the pointer
        count++;
    }
}

void PlotPixel(uint8_t row, uint8_t col, uint8_t color)
{
/*
Description:    This procedure modifies the display buffer at a specific
                location and sets the state to one of the allowed colors.

Arguments:          row - the row in which to plot the pixel
                    col - the column in which to plot the pixel
                    color - OFF, RED, GREEN, or YELLOW, the color of the
                            pixel
Return Values:      None.

Shared Variables:   displayBuf.
Global Variables:   None.
Local Variables:    address - the address of the red column-byte in 
                              displayBuf
            
Input:              None.
Output:             None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    Array.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    uint16_t address = &displayBuf + col;
    switch(color)
    {
        case OFF:  // set bit to 0 in red and green col
            *(address) &= !(0x80 >> row);
            *(address + NUM_COLS) &= !(0x80 >> row);
            break;
        case RED: // set bit to 1 in red col and 0 in green col
            *(address) |= (0x80 >> row);
            *(address + NUM_COLS) &= !(0x80 >> row);
            break;
        case GREEN: // set bit to 1 in green col and 0 in red col
            *(address) &= !(0x80 >> row);
            *(address + NUM_COLS) |= (0x80 >> row);
            break;
        case YELLOW: // set bit to 1 in red and green col
            *(address) |= (0x80 >> row);
            *(address + NUM_COLS) |= (0x80 >> row);
            break;
        default:
            break; // invalid color results in nothing being done
    }
}


void SetCursor(uint8_t row, uint8_t col, uint8_t on_color, uint8_t off_color)
{
/*
Description:    This procedure modifies the shared variables describing the
                cursor, placing it at the specified row and column while
                changing its on/off colors to the specified colors.

Arguments:          row - the row in which to plot the cursor
                    col - the column in which to plot the cursor
                    on_color - OFF, RED, GREEN, or YELLOW, the color of the
                               cursor in the on state
                    off_color - OFF, RED, GREEN, or YELLOW, the color of the
                                cursor in the off state
Return Values:      None.

Shared Variables:   cursor_row - the new cursor row
                    cursor_col - the new cursor column
                    cursor_on_color - the new cursor on-color
                    cursor_off_color - the new cursor off-color
Global Variables:   None.
Local Variables:    None.
            
Input:              None.
Output:             None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    cursor_row = row;
    cursor_col = col;
    cursor_on_color = on_color;
    cursor_off_color = off_color;
}

void displayGPIOInit()
{
/*
Description:    This procedure initializes the display GPIO ports for output
                and sets them to their initial states.

Arguments:          None.
Return Values:      None.

Shared Variables:   None.
Global Variables:   None.
Local Variables:    None.
            
Input:              None.
Output:             LED matrix.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // set display ports as outputs
    portMode(ROW_PORT, PORT_MODE_OUTPUT);
    portMode(RED_COL_PORT, PORT_MODE_OUTPUT);
    portMode(GREEN_COL_PORT, PORT_MODE_OUTPUT);

    // Start ports out low
    writePort(ROW_PORT, OFF);
    writePort(RED_COL_PORT, OFF);
    writePort(GREEN_COL_PORT, OFF);
}

void initDisplayVars()
{
/*
Description:    This procedure initializes the display shared variables to
                their starting state, to be modified later.

Arguments:          None.
Return Values:      None.

Shared Variables:   displayBuf - the shared display buffer
                    col_pattern_low - the bit patterns for column muxing
                    col_pattern_high
                    cursor_on - the cursor-on flag
                    cursor_row - the cursor position
                    cursor_col
                    cursor_on_color - the cursor on-color
                    cursor_off_color - the cursor off-color
                    BufLoc - the current pointer position in the display
                             buffer.
                    cursor_counter - used to keep track of how long 
                                     cursor has been in on/off states

Global Variables:   None.
Local Variables:    None.
            
Input:              None.
Output:             LED Matrix.

Error Handling:     None.
Algorithms:         None.
Data Structures:    Array.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Empty the display buffer
    ClearDisplay();

    // Turn the cursor entirely off at the origin
    SetCursor(0, 0, OFF, OFF);
    // Turn off the cursor_on flag
    clear_flag(cursor_on);
    // Initialize the cursor counter
    cursor_counter = CURSOR_TOGGLE_TIME;
    // Ready the col pattern bits at the first output column
    col_pattern_low = 0x01;
    col_pattern_high = 0x00;
    // Set display buffer pointer to the beginning of the array
    BufLoc = &displayBuf;
}

void HandleDisplay()
{
/*
Description:    This procedure is to be called within the timer interrupt
                handler. It will handle the multiplexing of the screen
                and the blinking of the cursor.

Arguments:          None.
Return Values:      None.

Shared Variables:   displayBuf - the shared display buffer
                    col_pattern_low - the bit patterns for column muxing
                    col_pattern_high
                    cursor_on - the cursor-on flag
                    cursor_row - the cursor position
                    cursor_col
                    cursor_on_color - the cursor on-color
                    cursor_off_color - the cursor off-color
                    BufLoc - the current pointer position in the display
                             buffer.
                    cursor_counter - used to keep track of how long 
                                     cursor has been in on/off states

Global Variables:   None.
Local Variables:    PreRowData - The holder for the row output which can
                                 be altered depending on the state of the
                                 cursor
                    cursor_color - the current value of the cursor's 
                                   color, corrected for toggling

Input:              None.
Output:             None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    Array.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Handle toggling cursor color
    cursor_counter--; // decrement the counter
    if(zero) // if the counter hit 0 (flag), reset it, and toggle cursor
    {
        cursor_counter += CURSOR_TOGGLE_TIME; // (ADIW)
        cursor_on = !cursor_on;
    }

    uint8_t PreRowData = *(BufLoc++) // get the current output row data
                                     // and increment the buffer pointer
    // Handle the cursor plotting
    if (current muxed column contains the cursor && \
        current cursor color != current muxed col color) // yellow counts as
                                                   // equaling red AND green
    {
        PreRowData &= !(0x80 >> cursor_row) // turn off row with the cursor
    }

    // Output to the matrix and update bit/mask patterns
    writePort(ROW_PORT, PreRowData);
    writePort(col_pattern_low, RED_COL_PORT);
    writePort(col_pattern_high, GREEN_COL_PORT);
    // transfer the column bit over, going opposite direction for
    // the high byte since the green port goes in reverse
    col_pattern_low = col_pattern_low << 1 // LSL col_pattern_low
    col_pattern_high = ROR(col_pattern_high) // ROR col_pattern_high
    if (carry) // If ROR results in a carry, then reached end of mux cycle
    {
        col_pattern_low = 0x01; // Reset the bit patterns
        col_pattern_high = 0x00;
        BufLoc = &displayBuf;
    }
}