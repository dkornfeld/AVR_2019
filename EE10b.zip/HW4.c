/*
David Kornfeld
EE10b HW4 pt1
*/

// Functions taken as givens
void portMode(port, mode);
void writePort(port, uint8_t data);
uint16_t Div16(uint16_t dividend, uint16_t divisor); // Straight from Glen's examples
uint8_t HIGH(uint16_t value); // Returns high 8 bits from value
uint8_t LOW(uint16_t value); // Returns low 8 bits from value

// Utility Code
void Speaker_Timer_Init();
void SPI_Speaker_GPIOInit();
void SPI_Init();

// Function prototypes
void PlayNote(uint16_t f);
void ReadEEROM(uint8_t address, *uint8_t rx_buf, uint8_t num_bytes);

// General Definitions
#define PORT_OFF        0x00 // All pins (enabled as outputs) set low

// SPI Definitions
#define SPI_SPEAKER_PORT        PORTB
#define BUF_LEN                 16 // SPI RX buffer length
#define EEROM_READ              0x06 // 110 read command
#define DUMMY_SEND              0x00 // Dummy data to prompt rx
#define CS_ON                   0x01 // Write to SPI port for CS high
#define CS_OFF                  0x00 // Write to SPI port for CS low

// Speaker Definitions
#define TOGGLE_ENABLE_SHIFT 6 // Timer1 control |= 1<<TOGGLE_ENABLE_SHIFT
                              // turns on the pin toggling for speaker
#define FREQUENCY_DIVIDEND  62500 // = 8MHz/(2*Prescaler) Prescaler is 64
                            // f_speaker = 8MHz/(2*Prescaler*(1+OCR_Value))

// SPI/Speaker Config Registers
#define SPI_ON                0b01110001 // Turn on SPI register
                            //  0------- SPI IRQ Disabled
                            //  -1------ SPI Enabled
                            //  --1----- MSB First
                            //  ---1---- Set as a master
                            //  ----00-- Use SPI mode 0
                            //  ------01 Prescaler of 16 (500kHz rate)

#define TIMER1_CONTROL_A      0b00000000
                            //  00------ Disconnect OCR1a (enabled by SW)
                            //  --0000-- Disconnect other OCR1s
                            //  ------00 CTC Output compare

#define TIMER1_CONTROL_B      0b00001011
                            //  00------ Don't care about input capture
                            //  --0----- Reserved
                            //  ---01--- CTC Output compare
                            //  -----011 Prescaler of 64

#define TIMER1_CONTROL_C      0b00000000
                            //  000----- Don't force output compare
                            //  ---00000 Reserved

// Data direction register for SPI and speaker
#define SPI_SPKR_DATA_DIR     0b00000111 
                            //  00-0---- Not connected (don't care)
                            //  --0----- Speaker pin (don't care)
                            //  ----0--- MISO - input
                            //  -----111 MOSI, SCK, SS - outputs

void Speaker_Timer_Init()
{
/*
Description:    This procedure initializes timer 1 for use with the
                speaker.

Arguments:          None.
Return Values:      None.

Shared Variables:   None.
Global Variables:   None.
Local Variables:    None.
            
Input:              None.
Output:             Speaker

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Set the control registers as defined in inc file
    // Toggling of pin starts out disabled
    // No initial OCR value set because speaker is off
    TCCR1A = TIMER1_CONTROL_A;
    TCCR1C = TIMER1_CONTROL_B;
    TCCR1C = TIMER1_CONTROL_C;
}

void PlayNote(uint16_t f)
{
/*
Description:    This procedure plays the speaker at frequency
                f. The speaker is disabled if f is 0.

Arguments:          f - 16 bit frequency value
Return Values:      None.

Shared Variables:   None.
Global Variables:   None.
Local Variables:    quot - Holder for division result
            
Input:              None.
Output:             Speaker

Error Handling:     None.
Algorithms:         Restoring division.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    uint16_t quot;
    // Turn off if 0 freq
    if(f == 0)
    {
        TCCR1A &= !(1 << TOGGLE_ENABLE_SHIFT); // Turn off toggling
        return;
    }
    // Use precalculated dividend to get OCR
    // value from the frequency argument
    quot = Div16(FREQUENCY_DIVIDEND, f);
    quot--; // Need to subtract one since frequency formula has 1+OCR

    // Write OCR value corresponding to proper frequency
    OCR1AH = HIGH(quot);
    OCR1AL = LOW(quot);
    // Turn on toggling
    TCCR1A |= (1 << TOGGLE_ENABLE_SHIFT);
}

void SPI_Speaker_GPIOInit()
{
/*
Description:    This procedure initializes the SPI and speaker GPIO
                pins to their proper starting states.

Arguments:          None.
Return Values:      None.

Shared Variables:   None.
Global Variables:   None.
Local Variables:    None.
            
Input:              SPI
Output:             SPI, Speaker

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Set proper data direction pin by pin
    portMode(SPI_SPEAKER_PORT, SPI_SPKR_DATA_DIR);
    // Turn off all pins on port to start
    writePort(SPI_SPEAKER_PORT, PORT_OFF);
}

void SPI_Init()
{
/*
Description:    This procedure initializes the SPI controller only.

Arguments:          None.
Return Values:      None.

Shared Variables:   None.
Global Variables:   None.
Local Variables:    None.
            
Input:              SPI
Output:             SPI

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    SPCR = SPI_ON // Enable the SPI with the specified settings
}

void ReadEEROM(uint8_t address, *uint8_t rx_buf, uint8_t num_bytes)
{
/*
Description:    This procedure reads num_bytes bytes from the EEROM
                from the address given and the data is stored at a 
                pointer passed as an argument.

Arguments:          address - The address to read from
                    rx_buf - The pointer to where to store data
                    num_bytes - The number of bytes to read
Return Values:      None (data is placed in specified memory location)

Shared Variables:   None.
Global Variables:   None.
Local Variables:    i - A counter
            
Input:              SPI from EEROM
Output:             SPI to EEROM

Error Handling:     None.
Algorithms:         None.
Data Structures:    Array.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    uint8_t i;
    // Take CS high
    writePort(SPI_SPEAKER_PORT, CS_ON);
    SPDR = EEROM_READ; // Send the read command
    while(SPIF == 0); // Wait for transmit complete
    SPDR = address; // Send the read address
    while(SPIF == 0); // Wait for transmit complete
    for (i=0; i<num_bytes; i++)
    {
        SPDR = DUMMY_SEND; // Send dummy data to get a byte back
        while(SPIF == 0); // Wait for transmit complete
        *(rx_buf++) = SPDR; // Store the rx data and inc pointer
    }
    // Take CS low
    writePort(SPI_SPEAKER_PORT, CS_OFF);
}
