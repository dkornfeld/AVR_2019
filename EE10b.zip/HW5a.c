/*
David Kornfeld
EE10b HW5 pt1
*/

// Global functions already written (or to be written), from other assignments #
// Functions to be written marked with /**/

// Switch Routines
int LRSwitch(void);
int UDSwitch(void);
int LeftRot(void);
int RightRot(void);
int DownRot(void);
int UpRot(void);

// Display Routines
void ClearDisplay();
void PlotPixel(uint8_t row, uint8_t col, uint8_t color);
void SetCursor(uint8_t row, uint8_t col, uint8_t on_color, uint8_t off_color);
void PlotCol(uint8_t col_number, uint8_t red_col, uint8_t green_col); /**/
void PlayAnimation(uint8_t *animationHead); /**/
void PlotImage(&LoseImage); 
void EnableBlinking(); /**/
void DisableBlinking(); /**/

// Speaker/EEROM Routines
void PlayNote(uint16_t f);
void ReadEEROM(uint8_t address, *uint8_t rx_buf, uint8_t num_bytes);
void PlaySound(uint16_t *soundHead); /**/

// Binario Routines
void ResetGame();
int CheckWin();
int BoardFull();
int CheckLegal(uint8_t row, uint8_t col);
void PlayMove(uint8_t row, uint8_t col);
void PlayIllegalSound();
void Win();
void Lose();
void HideCursor();
void ShowBoard();
void MoveCursor(uint8_t row, uint8_t col);

// Utility Code
uint24_t Div24by16(uint_24_t dividend, uint16_t divisor);
void delay(uint8_t centiseconds); /**/
uint8_t BitShiftLeft(uint8_t input, uint8_t num_shifts);
uint8_t BitShiftRight(uint8_t input, uint8_t num_shifts);

// Main function prototypes
void setup();
void mainLoop();

// Main function shared variables
int made_change;
uint8_t cursor_row;
uint8_t cursor_col;

// Main definitions
#define NUM_ROWS 8
#define NUM_COLS 8
#define TRUE 1
#define FALSE 0

// #############################################################################
void setup()
{
/*
Description:    This procedure sets up the main loop, initializing the board, 
				setting an initial position for the cursor, initializing other 
				shared variables, and plotting the current state of the game.

Arguments:      	None.
Return Values:  	None.

Shared Variables:   cursor_row(w) - the game cursor row position
                    cursor_col(w) - the game cursor column position
                    made_change(w) - indicates if the display should update or not
Global Variables:   None.
Local Variables:    None.
            
Input:          	None.
Output:         	LED Matrix.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    ResetGame();
    cursor_row = 0;
    cursor_col = 0;
    made_change = FALSE;
    MoveCursor(cursor_row, cursor_col);
}

void mainLoop()
{
/*
Description:    This procedure is the mainloop for the game of Binario. An 
				infinite loop is used to implement this, continually checking if
				there has been user input and responding accordingly, moving the
				cursor, or playing moves in the game. If a change has been made,
				the display buffer is updated. If the board is filled, a winning
				condition is checked.

Arguments:      	None.
Return Values:  	None.

Shared Variables:   cursor_row(r/w) - the game cursor row position
                    cursor_col(r/w) - the game cursor column position
                    made_change(w) - indicates if the display should update or not
Global Variables:   None.
Local Variables:    None.
            
Input:          	Rotary Encoders, Pushbuttons.
Output:         	LED Matrix.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    while(true){ // Loop forever
        // First, assume board doesn't change
        made_change = FALSE;

        // Check all user input
        if(UDSwitch()) // If reset button was pushed
        {
            ResetGame(); // Reset the game to initial state
        }

        if(LR_Switch()) // If play move butotn was pushed
        {
            if(CheckLegal(cursor_row, cursor_col)) // See if legal to play 
            {
                PlayMove(cursor_row, cursor_col); // If so, play the move there
                made_change = TRUE; // Mark the board for update
            }
            else
            {
                PlayIllegalSound(); // Else, show user that move was illegal
            }
        }
        if(LeftRot()) // If user rotated left
        {
            cursor_col--; // Move the cursor left
            if(cursor_col < 0) // if outside valid range
            {
                cursor_col = NUM_COLS - 1; // Reset cursor (wrap)
            }
            made_change = TRUE; // Mark cursor for update
        }
        if(RightRot()) // If user rotated right
        {
            cursor_col++; // Move the cursor right
            if(cursor_col >= NUM_COLS) // if outside valid range
            {
                cursor_col = 0; // Reset cursor (wrap)
            }
            made_change = TRUE; // Mark cursor for update
        }
        if(DownRot()) // If user rotated down
        {
            cursor_row--; // Move the cursor down
            if(cursor_row < 0) // If outside valid range
            {
                cursor_col = NUM_ROWS - 1; // Reset cursor (wrap)
            }
            made_change = TRUE; // Mark cursor for update
        }
        if(UpRot()) // If user rotated up
        {
            cursor_row++; // Move the cursor up
            if(cursor_row >= NUM_ROWS) // If outside valid range
            {
                cursor_row = 0; // Reset cursor (wrap)
            }
            made_change = TRUE; // Mark cursor for update
        }

        // If a change was made, process it
        if(made_change)
        {
            ShowBoard(); // Display the updated board
            MoveCursor(cursor_row, cursor_col); // And the updated cursor
            if(BoardFull()) // If all positions are filled, test for win
            {
                if(CheckWin()) // If game won, do winning routine
                {
                    Win();
                }
                else // Else, do the losing routine
                {
                    Lose();
                }
            }
        }
    }
}
