/*
David Kornfeld
EE10b HW5 pt1
*/

// Binario Routines -- Functions to be used to handle the game of Binario ######

// Shared variables
uint8_t board[3*NUM_COLS]; // The board object for the game
    // 1st set of columns: Red columns
    // 2nd set of columns: Green columns
    // 3rd set of columns: Locked(TRUE) or not(FALSE)

// Function Prototypes
void ResetGame();
int CheckWin();
int BoardFull();
int CheckLegal(uint8_t row, uint8_t col);
void PlayMove(uint8_t row, uint8_t col);
void PlayIllegalSound();
void Win();
void Lose();
void HideCursor();
void ShowBoard();
void MoveCursor(uint8_t row, uint8_t col);

// Booleans
#define TRUE 1
#define FALSE 0

// Color definitions
#define OFF 0
#define RED 1
#define GREEN 2
#define YELLOW 3

// Binario Definitions (most game parameters #defined for now; most will be user-
//						programmable in-game later)
#define GAME_NUMBER 0 // Which playing board to select

#define ILLEGAL_SOUND_FREQUENCY 200 // Hz
#define ILLEGAL_DELAY 20 // 200ms

#define WinAnimation TBD // Table in program memory
#define WinSound TBD // Table in program memory
#define WIN_DELAY 100 // 1 second

#define LoseSound TBD // Table in program memory
#define LoseImage TBD // Table in program memory
#define LOSE_DELAY 100 // 1 second

#define CURSOR_ON_COLOR RED // Declared globally since MoveCursor is an abstraction
#define CURSOR_OFF_COLOR GREEN

// Actual Code #################################################################

void ResetGame()
{
/*
Description:    This procedure resets all the game objects for the game of 
				Binario. The #define'd game parameter determines then which 
				gameboard is loaded in from memory. The proper colors are then 
				transferred to the gameboard object. The display buffer is then 
                loaded with the gameboard object to begin playing.

Arguments:      	None.
Return Values:  	None.

Shared Variables:   board(w) - The gameboard object
Global Variables:   None.
Local Variables:    i - A loop index
                    fixedPoints - Loaded data for fixed points from the loaded board
                    rawData - Solution data loaded from EEROM
                    redCol - For data manipulation to get proper data to gameboard
                    greenCol - For data manipulation to get proper data to gameboard
            
Input:          	SPI from EEROM
Output:         	SPI to EEROM

Error Handling:     None.
Algorithms:         None.
Data Structures:    Array.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    int i; // A counter
    // Holder variables for RX from EEROM
    uint8_t fixedPoints;
    uint8_t rawData;
    // To be transferred into our board structure
    uint8_t redCol;
    uint8_t greenCol;

    // Reset board with initial data
    for(i=0; i<NUM_COLS; i++) // Column, by column, read and put data where necessary
    {
        ReadEEROM(GAME_NUMBER*NUM_COLS + i, &rawData, 1); // Read the soln
        ReadEEROM((GAME_NUMBER+1)*NUM_COLS + i, &fixedPoints, 1); // Read fixed pts
        redCol = !rawData & fixedPoints; // Red = 0, so need to ! rawData before &'ing
        greenCol = rawData & fixedPoints; // Using & w/ fixedPoints gets color data
        board[i] = redCol; // Fill in the red column data
        board[i + NUM_COLS] = greenCol; // Fill in the green column data
        board[i + 2*NUM_COLS] = fixedPoints; // Fill in the fixed points
    }

    // Show the display buffer
    ShowBoard();
}

int BoardFull()
{
/*
Description:    This procedure determines if all the spaces in the gameboard are
                filled. If so, TRUE is returned. Otherwise, FALSE is returned.

Arguments:      	None.
Return Values:  	BoardFull(TRUE or FALSE)

Shared Variables:   board(r) - The gameboard object
Global Variables:   None.
Local Variables:    i - A loop index
            
Input:          	None.
Output:         	None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    Array.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    int i;
    for(i=0; i<NUM_COLS; i++)
    {
        if((board[i] | board[i + NUM_COLS]) == 0) // If red andgreen col i empty
        {
            return FALSE; // return that board isn't full
        }
    }

    return TRUE; // Otherwise, it is full
}


int CheckWin()
{
/*
Description:    This procedure checks if the gameboard is a winning one by
                comparing it agains the known solution data from memory. 
                The data from memory is converted to the form that matches
                the gameboard object and then the elements are compared,
                column by column.

Arguments:      	None.
Return Values:  	IsWin(TRUE or FALSE).

Shared Variables:   board(r) - The gameboard object
Global Variables:   None.
Local Variables:    i - A loop index
                    rawData - Solution data loaded from EEROM
                    redCol - For data manipulation to get proper data to gameboard
                    greenCol - For data manipulation to get proper data to gameboard
            
Input:          	SPI from EEROM
Output:         	SPI to EEROM

Error Handling:     None.
Algorithms:         None.
Data Structures:    Array.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    int i; // A counter
    // Holder variables for RX from EEROM
    uint8_t rawData;
    // To be used for comparison with our board
    uint8_t redCol;
    uint8_t greenCol;

    for(i=0; i<NUM_COLS; i++) // Col, by col, read soln and compare with board
    {
        ReadEEROM(GAME_NUMBER*NUM_COLS + i, &rawData, 1); // Read the soln
        redCol = !rawData // red = 0, so must invert to find red points as 1s
        greenCol = rawData // green = 1, so rawData looks like green col
        if(board[i] != redCol || board[i + NUM_COLS] != greenCol) // if not matching
        {
            return FALSE; // Return that board doesn't match
        }
    }

    return TRUE; // Otherwise the board matches, return won
}


int CheckLegal(uint8_t row, uint8_t col)
{
/*
Description:    This procedure determines if it is legal to play a move
                in the given row and column. If so, TRUE is returned;
                otherwise, FALSE is returned. This is done by accessing
                the part of the gameboard object that determines if points
                are fixed or not.

Arguments:      row(0 to NUM_ROWS - 1) - The row in which to check legality
                col(0 to NUM_COLS - 1) - The col in which to check legality
Return Values:  IsLegal(TRUE or FALSE).

Shared Variables:   board(r) - The gameboard object
Global Variables:   None.
Local Variables:    None.
            
Input:          	None.
Output:         	None.

Error Handling:     None.
Algorithms:         None.
Data Structures:    Array.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Isolate the bit from the board that indicates if the position is fixed
    // and figure out if it was a 0 - unfixed, (returning true)
    return ((board[2*NUM_COLS + col] & (1 << row)) == 0);
}

void PlayMove(uint8_t row, uint8_t col)
{
/*
Description:    This procedure plays a move in the specified position on
                the gameboard object. This is done by toggling the color 
                between red, green, and off. The gameboard object's
                columns are updated appropriately with nested if/elses

Arguments:      	row(0 to NUM_ROWS - 1) - The row in which to play the move
					col(0 to NUM_COLS - 1) - The col in which to play the move
Return Values:  	None.

Shared Variables:   board(r/w) - The gameboard object
Global Variables:   None.
Local Variables:    redCol - For data manipulation to get proper data from gameboard
                    greenCol - For data manipulation to get proper data from gameboard
            
Input:          	None.
Output:         	None.

Error Handling:     None. CheckLegal determines if move can be played, not here.
Algorithms:         None.
Data Structures:    Array.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Get the cols from the board object
    uint8_t redCol = board[col];
    uint8_t greenCol = board[NUM_COLS + col];
    // Modify the board object accordingly
    if((redCol & (1 << row)) != 0) // If the position is red
    {
        board[NUM_COLS + col] |= (1 << row); // Make the position green
        board[col] &= !(1 << row);
    }
    else if((greenCol & (1 << row)) != 0) // If the position is green
    {
        board[NUM_COLS + col] &= !(1 << row); // Make the position empty
        board[col] &= !(1 << row);
    }
    else // Else, the position is empty
    {
        board[col] |= (1 << row); // Make the position red
    }
}


void PlayIllegalSound()
{
/*
Description:    This procedure plays sound specified by #defined game parameters
                for a #defined amount of time, hanging all non-interrupt code.
                The speaker is then shut off. 

Arguments:      	None.
Return Values:  	None.

Shared Variables:   None.
Global Variables:   None.
Local Variables:    None.
            
Input:          	None.
Output:         	Speaker.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Play the bad note(s)
    PlayNote(ILLEGAL_SOUND_FREQUENCY);
    // Delay to let note play
    delay(ILLEGAL_DELAY);
    // And turn off speaker
    PlayNote(0);
}

void Win()
{
/*
Description:    This procedure is called when the game is won. First,
                a winning tune is played from program memory. Then, a
                winning animation is played from program memory while the
                cursor is hidden. The gameboard is then displayed for a set
                amount of time before resetting the game.

Arguments:      	None.
Return Values:  	None.

Shared Variables:   None.
Global Variables:   None.
Local Variables:    None.
            
Input:          	None.
Output:         	LED Matrix, Speaker.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Play the victory noise
    PlaySound(&WinSound);
    // And show the victory animation (whtout cursor)
    HideCursor();
    PlayAnimation(&WinAnimation);
    // Then, restore the original board to buffer
    ShowBoard();
    // And delay on it
    delay(WIN_DELAY);
    // Then reset the game
    ResetGame();
}

void Lose()
{
/*
Description:    This procedure is called when the game is lost. First,
                a losing tune is played from program memory. Then, a
                losing image is loadedfrom program memory while the
                cursor is hidden and the screen blinks. The gameboard is
                then restored to the display buffer and the cursor is put back.

Arguments:      	None.
Return Values:  	None.

Shared Variables:   None.
Global Variables:   None.
Local Variables:    None.
            
Input:          	None.
Output:         	LED Matrix, Speaker.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Play the losing noise
    PlaySound(&LoseSound);
    // And blink on a losing image (without cursor)
    HideCursor();
    PlotImage(&LoseImage);
    EnableBlinking();
    // Let it blink for a set time
    delay(LOSE_DELAY);
    // Turn off blinking
    DisableBlinking();
    // And restore original board to buffer
    ShowBoard();
    MoveCursor(0, 0); // Put the cursor back 
}

void HideCursor()
{
/*
Description:    This procedure hides the cursor by plotting it in
                an invalid location. This is useful for displaying
                animations or static images.

Arguments:      	None.
Return Values:  	None.

Shared Variables:   None.
Global Variables:   None.
Local Variables:    None.
            
Input:          	None.
Output:         	LED Matrix.

Error Handling:     None.
Algorithms:         None.
Data Structures:    None.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Plot the cursor in an invalid position (turning it off)
    SetCursor(NUM_ROWS, NUM_COLS, OFF, OFF);  
}

void ShowBoard()
{
/*
Description:    This procedure transfers the current gameboard object to
                the display buffer, column by column.

Arguments:      	None.
Return Values:  	None.

Shared Variables:   board(r) - The gameboard object.
Global Variables:   None.
Local Variables:    i - A loop index.
            
Input:          	None.
Output:         	LED Matrix.

Error Handling:     None.
Algorithms:         None.
Data Structures:    Array.
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    int i;
    for(i=0; i<NUM_COLS; i++) // Col by Col, plot game board on display buffer
    {
        PlotCol(i, board[i], board[i + NUM_COLS]);
    }
}

void MoveCursor(uint8_t row, uint8_t col)
{
/*
Description:    This procedure simply sets the cursor at the passed
                location, using fixed on/off colors as specified
                in #defined game paramters.

Arguments:      	row(0 to NUM_ROWS - 1) - The row in which to plot the cursor
					col(0 to NUM_COLS - 1) - The col in which to plot the cursor
Return Values:  	None.

Shared Variables:   None.
Global Variables:   None.
Local Variables:    None.
            
Input:          	None.
Output:         	LED Matrix.

Error Handling:     None. Cursor outside range isn't plotted.
Algorithms:         None.
Data Structures:    None..
Limitations:        None.
Known Bugs:         None.
Special Notes:      None.
*/
    // Plot the cursor with a globally defined set of colors (game parameters)
    SetCursor(row, col, CURSOR_ON_COLOR, CURSOR_OFF_COLOR);
}